const objetoPessoa ={
    nome: "Thauane",
    idade: 17,
    cpf: " 6792344123142",
    email:"thauane.lourenco@escola.pr.gov.br",

}

console.log( `O nome do cliente é ${objetoPessoa.nome} e sua idade é  ${ objetoPesoa.idade} anos`)