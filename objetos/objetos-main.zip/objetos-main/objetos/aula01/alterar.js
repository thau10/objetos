const pessoa = {
    nome: "Aline",
    profissao:"Biomedica",
};

console.log(pessoa.telefone);
pessoa.telefone = "43996700157",
console.log(pessoa.telefone);