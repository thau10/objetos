const informacoesPessoa = ["nome", "Thauane","idade","17","CPF"," 679234123142"];
const objetoPessoa ={
    nome: "Thauane",
    idade: 17,
    cpf: " 6792344123142",
    email:"thauane.lourenco@escola.pr.gov.br",

}